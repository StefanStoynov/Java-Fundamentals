package Contracts;

public interface SuperPower {

    String getName();

    double getPowerPoints();

}
